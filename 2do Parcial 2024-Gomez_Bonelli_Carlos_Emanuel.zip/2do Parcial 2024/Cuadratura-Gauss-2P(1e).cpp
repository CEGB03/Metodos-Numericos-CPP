#include <stdio.h>
#include <math.h>

// Función derivada exacta de f(x)
double derivada_exacta(double x) {
    return (2 * x) / (x * x + 1) - cos(x);
}

double cuadratura_gauss(double a, double b) {
    // Puntos de Gauss y pesos para 2 puntos
    double puntos[2] = { -1.0 / sqrt(3), 1.0 / sqrt(3) }; // Raíces de Gauss
    double pesos[2] = { 1.0, 1.0 }; // Pesos para Gauss 2 puntos

    // Centro del intervalo y su mitad (a + b)/2 y (b - a)/2
    double centro = (a + b) / 2;
    double mitad = (b - a) / 2;

    // Resultado de la integración usando cuadratura de Gauss
    double integral = 0.0;
    for (int i = 0; i < 2; i++) {
        double x = centro + mitad * puntos[i]; // Calcular el punto x_i
        integral += pesos[i] * derivada_exacta(x); // Evaluar f(x_i) y multiplicar por peso
    }

    // Multiplicar por la mitad del tamaño del intervalo
    integral *= mitad;

    return integral;
}

// Cálculo de la integral exacta (aproximación simbólica)
double integral_exacta(double a, double b) {
    // Calcular la integral exacta de la derivada exacta de f(x) en [1, 2]
    double integral = 0.0;
    int num_points = 1000; // Aumentar para mayor precisión
    double dx = (2.0 - 1.0) / num_points;
    for (int i = 0; i <= num_points; i++) {
        double x = 1.0 + i * dx;
        integral+= derivada_exacta(x) * dx;
    }
    return integral=0.87876;
}

int main() {
    double a = 1.0;
    double b = 2.0;

    // Calcular la integral usando Cuadratura de Gauss de 2 puntos
    double integral_gauss = cuadratura_gauss(a, b);

    // Calcular la integral exacta (aproximada simbólicamente)
    double integral_exacta_value = integral_exacta(a, b);

    // Calcular el error porcentual exacto
    double error_porcentual = fabs((integral_exacta_value - integral_gauss) / integral_exacta_value) * 100;

    // Mostrar los resultados
    printf("Integral usando Cuadratura de Gauss de 2 puntos: %lf\n", integral_gauss);
    printf("Valor exacto de la integral: %lf\n", integral_exacta_value);
    printf("Error porcentual exacto: %lf%%\n", error_porcentual);

    return 0;
}
