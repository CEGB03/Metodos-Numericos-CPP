#include <iostream>
#include <cmath>

using namespace std;

// Definición de la función f(x, y)
double f(double x, double y) {
    return (x * exp(x * x)) / y;  // f(x, y) = (x * exp(x^2)) / y
}

// Función exacta
double exacta(double x) {
    return exp(x * x / 2);  // Solución exacta: y = e^(x^2 / 2)
}

int main() {
    double x0 = 0, y0 = 1, h = 0.1, xn = 1.1;
    int n = (xn - x0) / h;
    double x[n+1], y[n+1];
    
    // Inicialización de los primeros valores
    x[0] = x0;
    y[0] = y0;
    
    // Paso 1: Método de Euler para calcular y1
    y[1] = y[0] + h * f(x[0], y[0]);
    
    // Ciclo para aplicar el método de 2 pasos hacia atrás
    for (int i = 1; i < n; i++) {
        x[i+1] = x[i] + h;
        y[i+1] = y[i] + h * (2 * f(x[i], y[i]) - f(x[i-1], y[i-1]));
    }
    
    // Imprimir los resultados y calcular el error absoluto
    for (int i = 0; i <= n; i++) {
        // Imprimir los valores de x, y calculados y el error absoluto
        double errorAbsoluto = abs(y[i] - exacta(x[i]));
        cout << "x = " << x[i] << ", y = " << y[i] << ", Error Absoluto = " << errorAbsoluto << endl;
    }

    return 0;
}
