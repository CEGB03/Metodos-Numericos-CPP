#include <iostream>
#include <cmath>

using namespace std;

// Definición de la función f(x, y)
double f(double x, double y) {
    return (x * exp(x * x)) / y;  // f(x, y) = (x * exp(x^2)) / y
}

// Función exacta
double exacta(double x) {
    return exp(x * x / 2);  // Solución exacta: y = e^(x^2 / 2)
}

int main() {
    double x0 = 0, y0 = 1, h = 0.1, xn = 1;
    int n = (xn - x0) / h;
    double x[n+1], y[n+1];
    
    // Inicialización de los primeros valores
    x[0] = x0;
    y[0] = y0;
    
    // Ciclo para aplicar el método RK4
    for (int i = 0; i < n; i++) {
        // Cálculo de los valores k1, k2, k3 y k4
        double k1 = h * f(x[i], y[i]);
        double k2 = h * f(x[i] + h/2, y[i] + k1/2);
        double k3 = h * f(x[i] + h/2, y[i] + k2/2);
        double k4 = h * f(x[i] + h, y[i] + k3);
        
        // Cálculo del siguiente valor de y
        y[i+1] = y[i] + (1.0/6.0) * (k1 + 2*k2 + 2*k3 + k4);
        
        // Avanzamos al siguiente valor de x
        x[i+1] = x[i] + h;
    }
    
    // Imprimir los resultados y calcular el error absoluto
    for (int i = 0; i <= n; i++) {
        // Imprimir los valores de x, y calculados y el error absoluto
        double errorAbsoluto = abs(y[i] - exacta(x[i]));
        cout << "x = " << x[i] << ", y = " << y[i] << ", Error Absoluto = " << errorAbsoluto << endl;
    }

    return 0;
}
