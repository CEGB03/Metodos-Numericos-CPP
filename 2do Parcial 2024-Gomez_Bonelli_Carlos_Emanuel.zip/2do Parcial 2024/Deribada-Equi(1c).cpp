#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    // Valores de S(x) para cada punto
    double x_values[] = {1.2000, 1.2625, 1.3250, 1.3875, 1.4500};
    double S_values[] = {-0.0400, -0.0002, 0.0432, 0.0898, 0.1395};
    double h = x_values[1]-x_values[0];

    // Cálculo de derivadas usando diferencias finitas
    double derivadas[5];
    
    // Diferencia hacia adelante en el primer punto
    derivadas[0] = (S_values[1] - S_values[0]) / h;

    // Diferencias centradas en los puntos intermedios
    for (int i = 1; i < 4; i++) {
        derivadas[i] = (S_values[i + 1] - S_values[i - 1]) / (2 * h);
    }

    // Diferencia hacia atrás en el último punto
    derivadas[4] = (S_values[4] - S_values[3]) / h;

    // Imprimir la tabla de derivadas
    cout << " x       Derivada S'(x) \n";
    cout << "--------------------------\n";
    for (int i = 0; i < 5; i++) {
        cout << fixed << setprecision(4) << x_values[i] << "\t" << derivadas[i] << endl;
    }

    return 0;
}
