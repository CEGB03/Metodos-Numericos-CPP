#include <iostream>
#include <cmath>
#include <iomanip>

double f_exact(double x) {
    return log(x * x + 1) - sin(x);
}

double S(double x) {
    // Polinomio obtenido en el inciso 1a: S(x) = -0.04 + 0.606969 * (x - 1.2) + 0.491014 * (x - 1.2)^2 - 0.187555 * (x - 1.2)^3
    double a = -0.04, b = 0.606969, c = 0.491014, d = -0.187555;
    double deltaX = x - 1.2;
    return a + b * deltaX + c * deltaX * deltaX + d * deltaX * deltaX * deltaX;
}

int main() {
    int num_points = 5;
    double x_start = 1.2, x_end = 1.45;
    double step = (x_end - x_start) / (num_points - 1);
    
    std::cout << " x\tf(x)\tS(x)\tError Absoluto\n";
    std::cout << "---------------------------------------\n";

    for (int i = 0; i < num_points; ++i) {
        double x = x_start + i * step;
        double exact_value = f_exact(x);
        double interpolated_value = S(x);
        double error_abs = fabs(exact_value - interpolated_value);

        std::cout << std::fixed << std::setprecision(4);
        std::cout << x << "\t" << exact_value << "\t" << interpolated_value << "\t" << error_abs << "\n";
    }

    return 0;
}
