#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

struct Spline {
    double a, b, c, d, x;
};

vector<Spline> cubicSpline(const vector<double>& x, const vector<double>& y) {
    int n = x.size() - 1;
    vector<Spline> splines(n);
    vector<double> h(n), alpha(n), l(n+1), mu(n), z(n+1);

    // Calcula h y alpha
    for (int i = 0; i < n; ++i) {
        h[i] = x[i+1] - x[i];
        alpha[i] = (3 / h[i]) * (y[i+1] - y[i]) - (3 / h[i-1]) * (y[i] - y[i-1]);
    }

    // Set condiciones de frontera
    l[0] = 1;
    mu[0] = z[0] = 0;

    // Calcular c
    for (int i = 1; i < n; ++i) {
        l[i] = 2 * (x[i+1] - x[i-1]) - h[i-1] * mu[i-1];
        mu[i] = h[i] / l[i];
        z[i] = (alpha[i] - h[i-1] * z[i-1]) / l[i];
    }

    l[n] = 1;
    z[n] = 0;
    splines[n-1].c = 0;

    // Back substitution
    for (int j = n-1; j >= 0; --j) {
        splines[j].c = z[j] - mu[j] * splines[j+1].c;
        splines[j].b = (y[j+1] - y[j]) / h[j] - h[j] * (splines[j+1].c + 2 * splines[j].c) / 3;
        splines[j].d = (splines[j+1].c - splines[j].c) / (3 * h[j]);
        splines[j].a = y[j];
        splines[j].x = x[j];
    }

    return splines;
}

double evaluateSpline(const vector<Spline>& splines, double x) {
    int n = splines.size();
    Spline spline;

    for (int i = 0; i < n; ++i) {
        if (x >= splines[i].x) spline = splines[i];
        else break;
    }

    double dx = x - spline.x;
    return spline.a + spline.b * dx + spline.c * dx * dx + spline.d * dx * dx * dx;
}

int main() {
    vector<double> x = {1.00, 1.20, 1.45, 1.78, 2.00};
    vector<double> y = {-0.1483, -0.0400, 0.1395, 0.4493, 0.7001};

    auto splines = cubicSpline(x, y);

    // Prueba de evaluación en un punto
    double x_eval = 1.3;
    double interpolado = evaluateSpline(splines, x_eval);
    cout << "Interpolado en x = " << x_eval << ": " << interpolado << endl;

    return 0;
}
