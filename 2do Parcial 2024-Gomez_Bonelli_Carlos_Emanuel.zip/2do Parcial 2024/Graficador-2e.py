# Paquetes
import numpy as np
import matplotlib.pyplot as plt

# Leo los datos
data1 = np.loadtxt('/home/cegb03/Documentos/Facu Ema/Metodos/Codigos/Metodos-Numericos-IUA-main-BB (Ema)/Metodos-Numericos-IUA-main/2do Parcial 2024/data-Exacta.txt') 
x1 = data1[:, 0]  # Primer columna
y1 = data1[:, 1]  # Segunda columna

# Leo los datos
data2 = np.loadtxt('/home/cegb03/Documentos/Facu Ema/Metodos/Codigos/Metodos-Numericos-IUA-main-BB (Ema)/Metodos-Numericos-IUA-main/2do Parcial 2024/data-Atras.txt')
x2 = data2[:, 0]  # Primer columna
y2 = data2[:, 1]  # Segunda columna

# Leo los datos
data3 = np.loadtxt('/home/cegb03/Documentos/Facu Ema/Metodos/Codigos/Metodos-Numericos-IUA-main-BB (Ema)/Metodos-Numericos-IUA-main/2do Parcial 2024/data-RK4.txt') 
x3 = data3[:, 0]  # Primer columna
y3 = data3[:, 1]  # Segunda columna

# Grafico
plt.plot(x1, y1, marker='o', color='r', label='Exacta')  # Grafico para la solución exacta
plt.plot(x2, y2, marker='x', color='g', label='2 Pasos Atrás')  # Grafico para el método de 2 pasos hacia atrás
plt.plot(x3, y3, marker='^', color='b', label='RK4')  # Grafico para el método RK4

# Personalización de los límites del gráfico (ajústalos según tus datos)
plt.xlim(0, 1.1)  # Límites del eje x
plt.ylim(0, 3)    # Límites del eje y

# Título y etiquetas
plt.title('Comparación de Métodos de Resolución de EDO')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
plt.show()

"""
https://matplotlib.org/stable/api/markers_api.html ---> distintos tipos de puntos
https://matplotlib.org/stable/gallery/color/named_colors.html ----> colores
https://matplotlib.org/stable/api/_as_gen/matplotlib.lines.Line2D.html#matplotlib.lines.Line2D.set_linestyle --> tipo de linea
"""