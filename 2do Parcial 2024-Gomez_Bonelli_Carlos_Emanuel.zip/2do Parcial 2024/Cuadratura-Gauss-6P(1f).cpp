#include <iostream>
#include <cmath>

using namespace std;


// Función que queremos integrar
double f(double x) {
    return (2 * x) / (x * x + 1) - cos(x);
}

double cuadratura_gauss() {
    // Puntos y pesos para Gauss de 6 puntos
    double x[4] = {-0.6612, -0.2386, 0.2386, 0.6612};
    double w[4] = {0.3608, 0.6544, 0.6544, 0.3608};
    
    double a = 1.0, b = 2.0;  // Límites de integración
    double integral = 0.0;
    
    for (int i = 0; i < 4; i++) {
        double xi = (b - a) / 2.0 * x[i] + (a + b) / 2.0;  // Transformar los puntos
        integral += w[i] * f(xi);  // Sumar el término ponderado
    }

    integral *= (b - a) / 2.0;  // Escalar la integral

    return integral;
}

int main() {
    double result = cuadratura_gauss();
    cout << "La integral usando cuadratura de Gauss de 6 puntos es: " << result << endl;
    return 0;
}
