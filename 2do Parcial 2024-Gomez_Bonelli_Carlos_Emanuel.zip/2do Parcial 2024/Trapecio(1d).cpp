#include <stdio.h>
#include <stdbool.h>
#include <math.h>

#define FILAS 5

// Función exacta para la derivada de f(x)
double derivada_exacta(double x) {
    return (2 * x) / (x * x + 1) - cos(x);
}

// Función para verificar si los puntos son equidistantes
bool sonEquidistantes(double arreglo[FILAS][2], int filas) {
    double diferencia = arreglo[1][0] - arreglo[0][0];
    for (int i = 1; i < filas - 1; i++) {
        if (arreglo[i + 1][0] - arreglo[i][0] != diferencia) {
            return false;
        }
    }
    return true;
}

// Método del trapecio para calcular la integral
void trapecioTabla() {
    double m[FILAS][2] = {
        {1.2000, 0.6368},  // x = 1.2000, S'(x) = 0.6368
        {1.2625, 0.6656},  // x = 1.2625, S'(x) = 0.6656
        {1.3250, 0.7200},  // x = 1.3250, S'(x) = 0.7200
        {1.3875, 0.7704},  // x = 1.3875, S'(x) = 0.7704
        {1.4500, 0.7952}   // x = 1.4500, S'(x) = 0.7952
    };

    int filas = FILAS;
    int n = filas - 1;
    bool flag = sonEquidistantes(m, filas);
    double suma = 0.0;

    // Verificar si los puntos son equidistantes
    if (flag) {
        suma = m[0][1] + m[filas - 1][1];
        for (int i = 1; i < n; i++) {
            suma += 2 * m[i][1];
        }
        double h = m[1][0] - m[0][0];  // Espaciado entre puntos
        double integral_aproximada = (h / 2) * suma;
        printf("\nLa integral usando el método del trapecio es: %lf\n", integral_aproximada);

        // Calcular la integral exacta de la derivada exacta de f(x) en [1, 2]
        double integral_exacta = 0.0;
        int num_points = 1000; // Aumentar para mayor precisión
        double dx = (2.0 - 1.0) / num_points;
        for (int i = 0; i <= num_points; i++) {
            double x = 1.0 + i * dx;
            integral_exacta += derivada_exacta(x) * dx;
        }

        // Imprimir el valor de la integral exacta
        printf("\nIntegral exacta: %lf\n", integral_exacta);

        // Calcular el error absoluto exacto
        double error_absoluto = fabs(integral_exacta - integral_aproximada);
        printf("\nError absoluto exacto: %lf\n", error_absoluto);
    } else {
        printf("\nLos puntos no son equidistantes\n");
        suma = 0;
        for (int i = 0; i < n; i++) {
            double h = m[i + 1][0] - m[i][0];  // Espaciado entre puntos
            suma += (h / 2) * (m[i + 1][1] + m[i][1]);
        }
        printf("\nLa integral usando el método del trapecio es: %lf\n", suma);

        // Calcular la integral exacta de la derivada exacta de f(x) en [1, 2]
        double integral_exacta = 0.0;
        int num_points = 1000; // Aumentar para mayor precisión
        double dx = (2.0 - 1.0) / num_points;
        for (int i = 0; i <= num_points; i++) {
            double x = 1.0 + i * dx;
            integral_exacta += derivada_exacta(x) * dx;
        }

        // Imprimir el valor de la integral exacta
        printf("\nIntegral exacta: %lf\n", integral_exacta);

        // Calcular el error absoluto exacto
        double error_absoluto = fabs(integral_exacta - suma);
        printf("\nError absoluto exacto: %lf\n", error_absoluto);
    }
}

int main() {
    trapecioTabla();
    return 0;
}
