#include <iostream>
#include <vector>

using namespace std;

struct Spline {
    double a, b, c, d, x;
};

vector<Spline> cubicSpline(const vector<double>& x, const vector<double>& y) {
    int n = x.size() - 1;
    vector<Spline> splines(n);
    vector<double> h(n), alpha(n), l(n+1), mu(n), z(n+1);

    // Calcula los intervalos h y alpha
    for (int i = 0; i < n; ++i) {
        h[i] = x[i+1] - x[i];
        if (i > 0) {
            alpha[i] = (3 / h[i]) * (y[i+1] - y[i]) - (3 / h[i-1]) * (y[i] - y[i-1]);
        }
    }

    // Establece las condiciones de frontera
    l[0] = 1;
    mu[0] = z[0] = 0;

    // Calcula los valores de c, l, mu y z
    for (int i = 1; i < n; ++i) {
        l[i] = 2 * (x[i+1] - x[i-1]) - h[i-1] * mu[i-1];
        mu[i] = h[i] / l[i];
        z[i] = (alpha[i] - h[i-1] * z[i-1]) / l[i];
    }

    l[n] = 1;
    z[n] = 0;
    splines[n-1].c = 0;

    // Sustitución regresiva para resolver los coeficientes
    for (int j = n - 1; j >= 0; --j) {
        splines[j].c = z[j] - mu[j] * splines[j+1].c;
        splines[j].b = (y[j+1] - y[j]) / h[j] - h[j] * (splines[j+1].c + 2 * splines[j].c) / 3;
        splines[j].d = (splines[j+1].c - splines[j].c) / (3 * h[j]);
        splines[j].a = y[j];
        splines[j].x = x[j];
    }

    return splines;
}

int main() {
    // Puntos dados en el problema
    vector<double> x = {1.00, 1.20, 1.45, 1.78, 2.00};
    vector<double> y = {-0.1483, -0.0400, 0.1395, 0.4493, 0.7001};

    // Genera los coeficientes spline
    auto splines = cubicSpline(x, y);

    // Encuentra e imprime el polinomio del intervalo x ∈ [1.2, 1.45]
    for (int i = 0; i < splines.size(); ++i) {
        if (x[i] == 1.2) {
            cout << "Polinomio en el intervalo [" << x[i] << ", " << x[i+1] << "]:" << endl;
            cout << "S(x) = " << splines[i].a
                      << " + " << splines[i].b << " * (x - " << splines[i].x << ")"
                      << " + " << splines[i].c << " * (x - " << splines[i].x << ")^2"
                      << " + " << splines[i].d << " * (x - " << splines[i].x << ")^3" << endl;
            break;
        }
    }

    return 0;
}
