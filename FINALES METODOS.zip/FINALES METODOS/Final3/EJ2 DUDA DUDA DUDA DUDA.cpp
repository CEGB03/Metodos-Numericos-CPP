#include <iostream>
#include <math.h>
#define FILAS 100
#define MAXCOLM 100
#define MAXROW 100
using namespace std;

double f(double v,double x){ //ingresar la funcion
	return 10*exp(0.05*v*pow(x,0.02));
}
void triangulacion(double a[FILAS][FILAS], double b[FILAS], double x[FILAS], int filas);
void retrostutitucion(double a[FILAS][FILAS], double b[FILAS], double x[FILAS], int filas);
void pivot(double a[FILAS][FILAS], double b[FILAS], int filas, int i);
double determinante(double a[FILAS][FILAS], double b[FILAS], double x[FILAS], int filas);

	int main(int argc, char *argv[]) {

		double a,b;
		double integral;
		double c0,c1,c2,x0,x1,x2;
		double vi[FILAS][2]={{0}};
		int fila = 21;
		printf("\nIngresar a\n");
		scanf("%lf",&a);
		printf("\nIngresar b\n");
		scanf("%lf",&b);
		double v = 0;
		for (int i = 0; i < 21 ; i++){
			c0 = 0.5555556;
			x0 = - 0.774596669; 
			c1 = 0.8888889; 
			x1 = 0.0;
			c2 = 0.5555556; 
			x2 = 0.774596669;
			integral = ((b-a)/2) * (c0 * f(v,((b-a)/2) * x0 + (b+a)/2) + c1 * f(v,((b-a)/2)*x1 + (b+a)/2) + c2 * f(v,((b-a)/2)*x2 + (b+a)/2));
			
			vi[i][0] = v;
			vi[i][1] = integral;
			printf("\n(%lf,%lf)",vi[i][0],vi[i][1]);
			v+=2.5;
		}
		
		//build matrix
		int  p = 5;
		double m[FILAS][FILAS];
		double b[FILAS];
			for (int i = 0; i < p; ++i) {
				double sumxy = 0;
				for (int j = 0; j < filas; ++j) {
					sumxy = sumxy + pow(vi[j][0], i) * vi[j][1];
				}
				b[i] = sumxy;
				for (int j = 0; j < p; ++j) {
					double sumx = 0;
					for (int k = 0; k < rows; ++k) {
						sumx = sumx + pow(vi[k][0], i + j);
					}
					m[i][j] = sumx;
				}
			}
			
			double x[FILAS];
			triangulacion(double m[FILAS][FILAS], double b[FILAS], double x[FILAS], int filas);
			

		return 0;
	}
	
		void triangulacion(double a[FILAS][FILAS], double b[FILAS], double x[FILAS], int filas){
			for (int i = 0 ; i < (filas - 1) ; i++){
				pivot(a, b, filas , i);
				for (int j = i + 1; j < filas; j++) {
					double factor = -a[j][i] / a[i][i];
					for (int k = 0; k < filas; ++k) {
						a[j][k] = a[i][k] * factor + a[j][k];
					}
					b[j] = b[i] * factor + b[j];
				}
			}
			
			double norma = determinante(a,b,x,filas);
			if(norma == 0.0){
				printf("\n\nmatriz singular");
			}else{
				retrostutitucion(a, b, x, filas);
			}
		}
void retrostutitucion(double a[FILAS][FILAS], double b[FILAS], double x[FILAS], int filas){
	double value = 0;
	value = b[filas - 1] / a[filas - 1][filas - 1];
	x[filas - 1] = value;
	for (int i = filas - 2; i >= 0; --i) {
		double sum = 0;
		for (int j = i + 1; j < filas; ++j) {
			sum = sum + a[i][j] * x[j];
		}
		value = (b[i] - sum) / a[i][i];
		x[i] = value;
	}
	printf("\n\n\n\nConjunto soluci�n de las asubn: \n");
	for (int i = 0; i < filas; ++i) {
		printf("a%d = %lf\n", i , x[i]);
	}
	
	printf("\n\n");
	printf("Polinomio Interpolador: \n");
	int power = 0;
	double suma = 0;
	for (int i = 0; i <= filas - 1; i++) {
		if (power == 0){
			printf("%lf", x[i]);
			suma+= x[i];
		}
		else {
			if (x[i] >= 0){
				printf(" + %lf*x^%d ", x[i], power);
				suma+= 550*pow(x[i],power);
			}
			else{
				printf(" %lf*x^%d", x[i], power);
				suma+= 550*pow(x[i],power);
			}
		}
		power++;
	}
	
	printf("\n El valor interpolado para la velocidad tal que da 550 es: %lf",suma);
}
void pivot(double a[FILAS][FILAS], double b[FILAS], int filas, int i){
	if (fabs(a[i][i]) < 0.0001) {
		for (int j = i + 1; j < filas; j++) {
			if (fabs(a[j][i]) > fabs(a[i][i])) {
				for (int k = i; k < filas; ++k) {
					printf("Se realizo pivoteo\n");
					double swap = a[i][k];
					a[i][k] = a[j][k];
					a[j][k] = swap;
				}
				double swap = b[i];
				b[i] = b[j];
				b[j] = swap;
			}
		}
	}
}
double determinante(double a[FILAS][FILAS], double b[FILAS], double x[FILAS], int filas){
	double norma = 1;
	for(int i = 0; i < filas ; i++){
		norma = norma * a[i][i];
	}
	return norma;
}
