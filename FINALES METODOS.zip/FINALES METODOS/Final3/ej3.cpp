#include <iostream>
#include <math.h>
using namespace std;

double f1(double v){//la forma que resuelve este metodo es ecuaciones de la forma: dy/dx = f(x,y) y necesitamos y(x0)= y0
	return v;		 // por ejemplo : dy/dx + 2xy = 0, donde tu f(xy) es -2xy
}
double f2(double v){
	return (80*9.8+0.5*(1.225*pow((300-6.5*exp(-3))/300 , -0.15))*v*v*30)/80;
}
	int main(int argc, char *argv[]) {
		double h;
		int n = 1000;
		double *x = (double *)malloc((n+1) * sizeof(double)); //con n+1 porq por ejemplo si tengo a y b y tengo 5 puntos, voy a necesitar el a,1,2,3,4,b
		double *y1 = (double *)malloc((n+1) * sizeof(double));
		double *y2 = (double *)malloc((n+1) * sizeof(double));
		x[0] = 0;
		y1[0] = 2300;
		y2[0] = 2;
		h = 1;

		for(int i = 0 ; i < n ; i++){ //menor a n porq cuando llegue a n-1, el for calcula el n+1
			x[i+1] =  x[i]+ h;
			y1[i+1] = y1[i] + h*f1(y1[i]);
			y2[i+1] = y2[i] + h*f2(y1[i]);
			printf("\n(%lf,%lf)", x[i+1], y2[i+1]);
		}
		return 0;
	}
