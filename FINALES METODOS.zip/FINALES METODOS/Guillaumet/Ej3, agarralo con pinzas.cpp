#include <iostream>
#include <math.h>
using namespace std;

double f1(double x, double y1,double y2){
	return y2;		 
}
double f2(double x, double y1,double y2){
	return -2*y2 - 5*y1;
}
		
int main(int argc, char *argv[]) {
	double a,b,h;
	int n = 100;
	h = 0.01;
	double *x = (double *)malloc((n+1) * sizeof(double)); //con n+1 porq por ejemplo si tengo a y b y tengo 5 puntos, voy a necesitar el a,1,2,3,4,b
	double *y1 = (double *)malloc((n+1) * sizeof(double));
	double *y2 = (double *)malloc((n+1) * sizeof(double));
	x[0] = 0;
	y1[0] = 0;
	y2[0] = 2;
	for (int i = 0; i < n; ++i) {
		
		
		
		double k1 = h * f1(x[i], y1[i], y2[i]);
		double l1 = h * f2(x[i], y1[i], y2[i]);
		
		double k2 = h * f1(x[i] + h / 2, y1[i] + k1 / 2, y2[i] + l1 / 2);
		double l2 = h * f2(x[i] + h / 2, y1[i] + k1 / 2, y2[i] + l1 / 2);
		
		double k3 = h * f1(x[i] + h / 2, y1[i] + k2 / 2, y2[i] + l2 / 2);
		double l3 = h * f2(x[i] + h / 2, y1[i] + k2 / 2, y2[i] + l2 / 2);
		
		double k4 = h * f1(x[i] + h, y1[i] + k3, y2[i] + l3);
		double l4 = h * f2(x[i] + h, y1[i] + k3, y2[i] + l3);
		
		y1[i+1] = y1[i] + (k1 + 2 * k2 + 2 * k3 + k4) / 6;
		y2[i+1]= y2[i] + (l1 + 2 * l2 + 2 * l3 + l4) / 6;
		
		x[i+1] = x[i] + h ;
			
		printf("(%.4lf,%.4lf)\n", x[i+1], y1[i+1]);
	}
	return 0;
}

