#include <iostream>
#include <math.h>
using namespace std;

double f1(double x, double y1,double y2){
	return y2;		 
}
	double f2(double x, double y1,double y2){
		return -2*y2 - 5*y1;
	}
	int main(int argc, char *argv[]) {
		double a,b,h;
		int n = 100;
		h = 0.01;
		double *x = (double *)malloc((n+1) * sizeof(double)); //con n+1 porq por ejemplo si tengo a y b y tengo 5 puntos, voy a necesitar el a,1,2,3,4,b
		double *y1 = (double *)malloc((n+1) * sizeof(double));
		double *y2 = (double *)malloc((n+1) * sizeof(double));
		x[0] = 0;
		y1[0] = 0;
		y2[0] = 2;
		
		for(int i = 0 ; i < n ; i++){ //menor a n porq cuando llegue a n-1, el for calcula el n+1
			x[i+1] =  x[i]+ h;
			y1[i+1] = y1[i] + h*f1(x[i],y1[i],y2[i]);
			y2[i+1] = y2[i] + h*f2(x[i],y1[i],y2[i]);
			printf("(%.4lf,%.4lf)\n", x[i+1], y1[i+1]);
		}
		return 0;
	}
